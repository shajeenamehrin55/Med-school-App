package com.medpulse.synergy

/**
 * Simple in-memory state shared between MainActivity (which starts/stops
 * a session from the web UI) and LockdownAccessibilityService (which
 * enforces it at the OS level). For production, persist this in
 * SharedPreferences so a killed process doesn't silently drop lockdown.
 */
object LockdownState {
    @Volatile var isActive: Boolean = false
    @Volatile var activeUntil: Long = 0L
    @Volatile var blockedPackages: Set<String> = emptySet()

    fun isCurrentlyLocked(): Boolean {
        if (!isActive) return false
        if (System.currentTimeMillis() > activeUntil) {
            isActive = false
            return false
        }
        return true
    }
}
