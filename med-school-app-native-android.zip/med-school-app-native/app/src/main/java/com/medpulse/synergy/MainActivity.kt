package com.medpulse.synergy

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

/**
 * Wraps the existing PWA (in assets/web/) in a WebView so the whole
 * study app ships as a normal Android app. The real "phone-wide
 * lockdown" work happens in LockdownAccessibilityService, which the
 * user must separately enable in system Accessibility settings —
 * Android does not allow any app to auto-enable that permission.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.webViewClient = WebViewClient()

        // Bridge: JS calls Android.requestAccessibilityPermission() from
        // Settings screen to jump straight to the OS permission page.
        webView.addJavascriptInterface(NativeBridge(this), "AndroidBridge")

        webView.loadUrl("file:///android_asset/web/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class NativeBridge(private val activity: MainActivity) {
    @android.webkit.JavascriptInterface
    fun requestAccessibilityPermission() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        activity.startActivity(intent)
    }

    @android.webkit.JavascriptInterface
    fun startLockdown(blockedPackagesCsv: String, minutes: Int) {
        LockdownState.blockedPackages = blockedPackagesCsv.split(",").map { it.trim() }.toSet()
        LockdownState.activeUntil = System.currentTimeMillis() + minutes * 60_000L
        LockdownState.isActive = true
    }

    @android.webkit.JavascriptInterface
    fun stopLockdown() {
        LockdownState.isActive = false
    }
}
