package com.medpulse.synergy

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * This is the actual mechanism that makes phone-wide app blocking
 * possible: an AccessibilityService gets notified whenever the
 * foreground window changes, anywhere on the phone. If a lockdown
 * session is active and the user has switched to a blocked app,
 * this brings MedPulse back to the front.
 *
 * IMPORTANT — Play Store policy:
 * Google requires a clear, prominent, in-app disclosure of exactly
 * why Accessibility access is requested before the OS permission
 * screen is shown (a "why we need this" screen), and the app's
 * Play Console listing must declare Accessibility usage under
 * Data Safety / Permissions declarations. Apps that request
 * Accessibility without an obvious accessibility-adjacent purpose
 * (like app-blocking / digital wellbeing) get flagged during
 * review — expect to submit a justification and possibly a demo
 * video. Budget review time for this before a launch date.
 */
class LockdownAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!LockdownState.isCurrentlyLocked()) return

        val pkg = event.packageName?.toString() ?: return
        val ownPackage = applicationContext.packageName

        if (pkg != ownPackage && LockdownState.blockedPackages.contains(pkg)) {
            // Bring MedPulse back to the foreground.
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(intent)
        }
    }

    override fun onInterrupt() { /* no-op */ }
}
