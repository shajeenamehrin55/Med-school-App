/* ============================================================
   MedPulse Synergy — app.js
   All data is real and persisted in localStorage (namespaced).
   No mock numbers: every stat on screen is computed from
   actual stored state.
   ============================================================ */

const STORE_KEY = 'mps_v1';

const DEFAULT_STATE = {
  profile: {
    persona: 'kerala-uae',
    stage: 'y1',
    prayerCity: 'Dubai',
    prayerCountry: 'UAE'
  },
  streak: { count: 0, lastStudyDate: null },
  cards: [],          // flashcards (seeded on first run)
  studyLog: [],        // {date, minutes, task}
  routines: { selected: null, dayIndex: 0, resetStartDate: null },
  research: [],         // {id, title, stage, notes}
  roadmap: { pathway: 'usa', stagesDone: [] },
  prefs: { nutrition: null, workout: null }
};

function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return structuredClone(DEFAULT_STATE);
    const parsed = JSON.parse(raw);
    return { ...structuredClone(DEFAULT_STATE), ...parsed,
      profile: { ...DEFAULT_STATE.profile, ...(parsed.profile||{}) },
      streak: { ...DEFAULT_STATE.streak, ...(parsed.streak||{}) },
      routines: { ...DEFAULT_STATE.routines, ...(parsed.routines||{}) },
      roadmap: { ...DEFAULT_STATE.roadmap, ...(parsed.roadmap||{}) },
      prefs: { ...DEFAULT_STATE.prefs, ...(parsed.prefs||{}) }
    };
  } catch(e){
    console.error('state load failed', e);
    return structuredClone(DEFAULT_STATE);
  }
}
function saveState(){ localStorage.setItem(STORE_KEY, JSON.stringify(state)); }

let state = loadState();

/* ---------------- Seed deck (first run only) ---------------- */
const SEED_CARDS = [
  {cat:'Cardiology', front:'54M, sudden tearing chest pain radiating to back, HTN history, widened mediastinum on CXR — diagnosis and first drug class?', back:'Aortic dissection. First-line: IV beta-blocker (e.g. esmolol/labetalol) to drop heart rate before any vasodilator, to avoid reflex tachycardia worsening shear stress.'},
  {cat:'Cardiology', front:'Which murmur increases with squatting and decreases with Valsalva/standing?', back:'Most murmurs (e.g. aortic stenosis) get louder with squatting (increased venous return/afterload) and softer with Valsalva. HOCM is the classic exception — it does the opposite.'},
  {cat:'Cardiology', front:'JVP with prominent "a" wave — think of what two conditions?', back:'Conditions with resistance to right atrial emptying: tricuspid stenosis and pulmonary hypertension (right ventricular hypertrophy).'},
  {cat:'Pharmacology', front:'Drug class causing dry cough and angioedema, mechanism?', back:'ACE inhibitors — block bradykinin breakdown, so bradykinin accumulates in the lungs/tissue, causing cough and angioedema.'},
  {cat:'Pharmacology', front:'Aminoglycoside + loop diuretic — combined toxicity?', back:'Ototoxicity is additive/synergistic — both damage the cochlea, so co-administration raises hearing-loss risk substantially.'},
  {cat:'Pharmacology', front:'First-line drug for status epilepticus, and second-line if it fails?', back:'First-line: IV benzodiazepine (lorazepam/diazepam). If seizure continues: IV fosphenytoin/phenytoin or valproate/levetiracetam.'},
  {cat:'Microbiology', front:'Gram-positive cocci in clusters, catalase +, coagulase + — organism and classic toxin-mediated disease?', back:'Staphylococcus aureus. Toxic shock syndrome (TSST-1 superantigen) and food poisoning (preformed enterotoxin, rapid onset vomiting).'},
  {cat:'Microbiology', front:'Currant-jelly sputum in an alcoholic — organism?', back:'Klebsiella pneumoniae — thick mucoid capsule gives the currant-jelly appearance; classic in alcoholics and diabetics.'},
  {cat:'Microbiology', front:'Rusty-colored sputum, lobar pneumonia, most common cause?', back:'Streptococcus pneumoniae — the most common cause of community-acquired lobar pneumonia.'},
  {cat:'Renal', front:'Nephrotic-range proteinuria + normal complement + "spike and dome" on EM — diagnosis?', back:'Membranous nephropathy — subepithelial immune deposits producing the spike-and-dome pattern; complement levels are usually normal.'},
  {cat:'Renal', front:'Child with nephrotic syndrome, effacement of podocyte foot processes on EM, normal light microscopy — diagnosis and treatment?', back:'Minimal change disease. Treat with corticosteroids — most children respond well.'},
  {cat:'Renal', front:'Winter-worsening cola-colored urine 1-2 days after URI — diagnosis?', back:'IgA nephropathy (Berger disease) — presents with gross hematuria shortly (24-48h) after a mucosal infection, unlike post-strep GN which lags 1-3 weeks.'},
  {cat:'Endocrinology', front:'Thin, anxious, heat-intolerant patient with diffuse goiter and exophthalmos — diagnosis and mechanism?', back:'Graves disease — autoantibodies (TSI) stimulate the TSH receptor, causing diffuse hyperplasia and hyperthyroidism; exophthalmos is from retro-orbital fibroblast/GAG deposition.'},
  {cat:'Endocrinology', front:'DKA vs HHS — key distinguishing lab feature?', back:'DKA: significant ketosis/acidosis, usually type 1 diabetes. HHS: much higher glucose, minimal ketosis, seen in type 2 diabetes, often with more profound dehydration and altered mental status.'},
  {cat:'Endocrinology', front:'Moon facies, buffalo hump, purple striae, proximal muscle weakness — screening test?', back:'Cushing syndrome. Screen with low-dose dexamethasone suppression test or 24h urinary free cortisol.'},
  {cat:'Neurology', front:'Contralateral leg weakness worse than arm — which artery/lesion?', back:'Anterior cerebral artery (ACA) infarct — supplies the medial motor cortex (leg/foot homunculus region).'},
  {cat:'Neurology', front:'Resting tremor, bradykinesia, rigidity, postural instability — pathology and neurotransmitter deficit?', back:'Parkinson disease — loss of dopaminergic neurons in the substantia nigra pars compacta (dopamine deficiency in the nigrostriatal pathway).'},
  {cat:'Neurology', front:'CN palsy: ptosis, "down and out" eye, dilated pupil — which nerve, and cause to worry about first?', back:'CN III (oculomotor) palsy. A pupil-involving CN III palsy is a posterior communicating artery aneurysm until proven otherwise (surgical emergency).'}
];

if (state.cards.length === 0) {
  const now = Date.now();
  state.cards = SEED_CARDS.map((c,i)=>({
    id: 'c'+i, cat:c.cat, front:c.front, back:c.back,
    due: now, interval: 0, ease: 2.5, reps: 0, lapses: 0
  }));
  saveState();
}

/* ---------------- Spaced repetition (SM-2 derived) ---------------- */
/* Ratings: 0 Again, 1 Hard, 2 Good, 3 Easy */
function scheduleCard(card, rating){
  const DAY = 86400000;
  if (rating === 0) {
    card.lapses++; card.reps = 0; card.interval = 0;
    card.ease = Math.max(1.3, card.ease - 0.2);
    card.due = Date.now() + 10*60*1000; // 10 min relearn
    return card;
  }
  card.reps++;
  if (rating === 1) card.ease = Math.max(1.3, card.ease - 0.15);
  if (rating === 3) card.ease += 0.15;

  if (card.reps === 1) card.interval = rating===1 ? 1 : (rating===3 ? 3 : 1);
  else if (card.reps === 2) card.interval = rating===1 ? 2 : (rating===3 ? 7 : 4);
  else card.interval = Math.round(card.interval * card.ease * (rating===1?0.8:1));

  card.due = Date.now() + card.interval*DAY;
  return card;
}
function dueCards(){ return state.cards.filter(c=>c.due <= Date.now()); }
function cardsMastered(){ return state.cards.filter(c=>c.reps>=2 && c.interval>=21).length; }

/* ---------------- Streak ---------------- */
function todayStr(){ return new Date().toISOString().slice(0,10); }
function logStudyMinutes(minutes, task){
  state.studyLog.push({date: Date.now(), minutes, task});
  const t = todayStr();
  if (state.streak.lastStudyDate !== t) {
    const y = new Date(Date.now()-86400000).toISOString().slice(0,10);
    state.streak.count = (state.streak.lastStudyDate === y) ? state.streak.count+1 : 1;
    state.streak.lastStudyDate = t;
  }
  saveState();
}
function studyMinutesLast7d(){
  const cutoff = Date.now() - 7*86400000;
  return state.studyLog.filter(l=>l.date>=cutoff).reduce((a,l)=>a+l.minutes,0);
}

/* ---------------- Prayer times (Aladhan API) ---------------- */
const PRAYER_ORDER = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
async function fetchPrayerTimes(city, country){
  const url = `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=2`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('prayer api failed');
  const json = await res.json();
  return json.data.timings;
}
function nextPrayer(timings){
  const now = new Date();
  const todayBase = now.toISOString().slice(0,10);
  let best = null;
  for (const name of PRAYER_ORDER){
    const raw = timings[name]; if(!raw) continue;
    const t = new Date(`${todayBase}T${raw.split(' ')[0]}:00`);
    if (t > now && (!best || t < best.time)) best = {name, time:t};
  }
  if (!best){ // all passed today -> Fajr tomorrow (approx, same time)
    const raw = timings['Fajr'];
    const t = new Date(`${todayBase}T${raw.split(' ')[0]}:00`);
    t.setDate(t.getDate()+1);
    best = {name:'Fajr', time:t};
  }
  return best;
}
function formatCountdown(ms){
  if (ms<0) ms=0;
  const h = Math.floor(ms/3600000);
  const m = Math.floor((ms%3600000)/60000);
  return `${h}h ${m}m`;
}

/* ---------------- Routines ---------------- */
const ROUTINES = {
  'uae-kerala': {label:'🌴 UAE/Kerala Modern Med Student', blocks:[
    ['5:30 AM','Fajr + 5 Ayahs'],['6:00','Cardio/mobility'],['7:00','Breakfast + pre-lecture preview'],
    ['8:00–1:00','Lectures / rotations'],['2:00','Dhuhr + lunch'],['2:30–5:00','Active recall + flashcards'],
    ['5:30','Asr'],['6:00–8:00','Clinical reading / research'],['8:00','Maghrib + dinner'],
    ['9:00–10:30','AuraFlash review'],['10:30','Isha'],['11:00','Wind down / sleep']
  ]},
  'grind-12h': {label:'🔥 USMLE 12-Hour Grind', blocks:[
    ['6:00 AM','Wake + Fajr'],['6:30–9:30','UWorld block 1 + review'],['9:30','Breakfast'],
    ['10:00–1:00','UWorld block 2 + review'],['1:00','Dhuhr + lunch'],['1:30–4:30','First Aid deep dive'],
    ['4:30','Asr'],['5:00–7:00','Flashcard review (AuraFlash)'],['7:00','Maghrib + dinner'],
    ['7:30–9:30','Weak-topic remediation'],['9:30','Isha'],['10:00','Sleep']
  ]},
  'night-owl': {label:'🦉 Night Owl Phase 1 (1am–9am)', blocks:[
    ['1:00 AM','Deep-focus block 1'],['3:00','Short break'],['3:30','Deep-focus block 2'],
    ['5:30','Fajr'],['6:00','Light review / flashcards'],['7:30','Breakfast'],['8:00–9:00','Wind down, sleep prep']
  ]},
  'cram': {label:'⚡ Pre-Exam High-Yield Cram', blocks:[
    ['Hour 0–2','Full flashcard deck sweep (due + hardest)'],['Hour 2–4','First Aid buzzwords only'],
    ['Hour 4–4.5','Break + prayer'],['Hour 4.5–6.5','Weakest-category drilling'],['Hour 6.5–7','Final recall pass']
  ]}
};

/* ---------------- Lockdown / focus timer ---------------- */
let lockdownState = { running:false, seconds:0, total:0, task:'', timerId:null };
function startLockdown(minutes, task){
  lockdownState = { running:true, seconds:minutes*60, total:minutes*60, task, timerId:null };
  document.getElementById('lockdown-task').textContent = task || 'Focus session';
  document.getElementById('lockdown-overlay').classList.add('active');
  document.getElementById('lockdown-warning').classList.remove('show');
  renderLockdownTimer();
  lockdownState.timerId = setInterval(()=>{
    lockdownState.seconds--;
    renderLockdownTimer();
    if (lockdownState.seconds<=0) finishLockdown(true);
  },1000);
  // try fullscreen for stronger in-app lock feel
  document.documentElement.requestFullscreen?.().catch(()=>{});
}
function renderLockdownTimer(){
  const m = Math.floor(lockdownState.seconds/60).toString().padStart(2,'0');
  const s = (lockdownState.seconds%60).toString().padStart(2,'0');
  document.getElementById('lockdown-clock').textContent = `${m}:${s}`;
}
function finishLockdown(completed){
  clearInterval(lockdownState.timerId);
  document.getElementById('lockdown-overlay').classList.remove('active');
  if (document.fullscreenElement) document.exitFullscreen?.().catch(()=>{});
  if (completed){
    const minutesDone = Math.round(lockdownState.total/60);
    logStudyMinutes(minutesDone, lockdownState.task);
    showToast(`Session logged: ${minutesDone} min — streak ${state.streak.count} 🔥`);
    renderDashboard();
  }
  lockdownState.running = false;
}
document.addEventListener('visibilitychange', ()=>{
  if (lockdownState.running && document.hidden){
    document.getElementById('lockdown-warning').classList.add('show');
    document.getElementById('lockdown-warning').textContent = '⚠ You left the app during a locked session. This app can only block navigation within itself — for full phone-wide blocking, use the native build (see Settings).';
  }
});

/* ---------------- Toast ---------------- */
function showToast(msg){
  const el = document.getElementById('toast');
  el.textContent = msg; el.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(()=>el.classList.remove('show'), 3200);
}

/* ---------------- Rendering ---------------- */
function matchReadiness(){
  // real (if simplistic) formula from actual stored progress, not a mock constant
  const mastered = cardsMastered();
  const totalCards = state.cards.length || 1;
  const cardScore = Math.min(1, mastered/totalCards) * 40;
  const streakScore = Math.min(1, state.streak.count/30) * 25;
  const stagesScore = (state.roadmap.stagesDone.length/4) * 25;
  const researchScore = Math.min(1, state.research.length/3) * 10;
  return Math.round(cardScore+streakScore+stagesScore+researchScore);
}

async function renderDashboard(){
  document.getElementById('stat-streak').textContent = state.streak.count;
  document.getElementById('stat-due').textContent = dueCards().length;
  document.getElementById('stat-readiness').textContent = matchReadiness()+'%';
  document.getElementById('stat-week-min').textContent = studyMinutesLast7d();
  try{
    const timings = await fetchPrayerTimes(state.profile.prayerCity, state.profile.prayerCountry);
    const np = nextPrayer(timings);
    document.getElementById('stat-prayer').textContent = np.name;
    document.getElementById('stat-prayer-sub').textContent = 'in ' + formatCountdown(np.time-new Date());
  }catch(e){
    document.getElementById('stat-prayer').textContent = '—';
    document.getElementById('stat-prayer-sub').textContent = 'offline';
  }
}

function renderDeckOverview(){
  const el = document.getElementById('deck-stats');
  el.innerHTML = `
    <div class="list-item"><span>Cards mastered (interval ≥21d)</span><span class="chip">${cardsMastered()} / ${state.cards.length}</span></div>
    <div class="list-item"><span>Due right now</span><span class="chip">${dueCards().length}</span></div>
    <div class="list-item"><span>Total lapses</span><span class="chip">${state.cards.reduce((a,c)=>a+c.lapses,0)}</span></div>
  `;
}

let studyQueue = [];
let studyIndex = 0;
function beginStudySession(){
  studyQueue = dueCards();
  studyIndex = 0;
  renderStudyCard();
}
function renderStudyCard(){
  const wrap = document.getElementById('study-area');
  if (studyQueue.length === 0){
    wrap.innerHTML = `<div class="empty-state">No cards due right now. Nice work — check back later or study ahead.</div>`;
    return;
  }
  if (studyIndex >= studyQueue.length){
    wrap.innerHTML = `<div class="empty-state">Session complete — ${studyQueue.length} cards reviewed. 🎉</div>`;
    logStudyMinutes(Math.max(1, Math.round(studyQueue.length*0.5)), 'Flashcard review');
    renderDashboard(); renderDeckOverview();
    return;
  }
  const card = studyQueue[studyIndex];
  wrap.innerHTML = `
    <div class="deck-progress"><span>Card ${studyIndex+1} of ${studyQueue.length}</span><span>${card.cat}</span></div>
    <div class="flashcard" id="flip-card">
      <div class="eyebrow">Question</div>
      <div class="front">${card.front}</div>
      <div class="back">${card.back}</div>
      <div class="hint">Click to reveal</div>
    </div>
    <div class="rate-row" id="rate-row" style="display:none">
      <button class="rate-btn rate-again" data-r="0">Again<small>&lt;10m</small></button>
      <button class="rate-btn rate-hard" data-r="1">Hard<small>~2d</small></button>
      <button class="rate-btn rate-good" data-r="2">Good<small>~4d</small></button>
      <button class="rate-btn rate-easy" data-r="3">Easy<small>~7d+</small></button>
    </div>
  `;
  document.getElementById('flip-card').onclick = ()=>{
    document.getElementById('flip-card').classList.add('revealed');
    document.getElementById('rate-row').style.display = 'grid';
  };
  document.querySelectorAll('.rate-btn').forEach(b=>{
    b.onclick = (e)=>{
      e.stopPropagation();
      scheduleCard(card, parseInt(b.dataset.r));
      saveState();
      studyIndex++;
      renderStudyCard();
    };
  });
}

function renderRoutines(){
  const sel = document.getElementById('routine-select');
  sel.innerHTML = Object.entries(ROUTINES).map(([k,v])=>`<option value="${k}">${v.label}</option>`).join('');
  sel.value = state.routines.selected || Object.keys(ROUTINES)[0];
  renderRoutineBlocks();
}
function renderRoutineBlocks(){
  const key = document.getElementById('routine-select').value;
  const r = ROUTINES[key];
  document.getElementById('routine-blocks').innerHTML = r.blocks.map(([t,d])=>
    `<div class="list-item"><span class="chip">${t}</span><span>${d}</span></div>`).join('');
}

function renderResearch(){
  const el = document.getElementById('research-list');
  if (state.research.length===0){ el.innerHTML = `<div class="empty-state">No projects tracked yet. Add your first below.</div>`; return; }
  el.innerHTML = state.research.map((r,i)=>`
    <div class="list-item">
      <span>${r.title} <span class="chip">${r.stage}</span></span>
      <button class="btn ghost small" onclick="removeResearch(${i})">Remove</button>
    </div>`).join('');
}
function removeResearch(i){ state.research.splice(i,1); saveState(); renderResearch(); }

function renderRoadmap(){
  const stages = ['Core Board Exams','Clinical Electives & LoRs','Research & Papers','Match / Interviews'];
  const el = document.getElementById('roadmap-stages');
  el.innerHTML = stages.map((s,i)=>{
    const done = state.roadmap.stagesDone.includes(i);
    return `<div class="list-item">
      <span>STAGE ${i+1} — ${s}</span>
      <button class="btn ${done?'':'ghost'} small" onclick="toggleStage(${i})">${done?'✓ Done':'Mark done'}</button>
    </div>`;
  }).join('');
}
function toggleStage(i){
  const idx = state.roadmap.stagesDone.indexOf(i);
  if (idx>-1) state.roadmap.stagesDone.splice(idx,1); else state.roadmap.stagesDone.push(i);
  saveState(); renderRoadmap(); renderDashboard();
}

/* ---------------- Nav / init ---------------- */
function switchView(name){
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.getElementById('view-'+name).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.view===name));
  if (name==='study') { beginStudySession(); renderDeckOverview(); }
  if (name==='routine') renderRoutines();
  if (name==='research') renderResearch();
  if (name==='roadmap') renderRoadmap();
  if (name==='dashboard') renderDashboard();
}

function initSettingsForm(){
  document.getElementById('setting-persona').value = state.profile.persona;
  document.getElementById('setting-stage').value = state.profile.stage;
  document.getElementById('setting-city').value = state.profile.prayerCity;
  document.getElementById('setting-country').value = state.profile.prayerCountry;
}

function wireUp(){
  document.querySelectorAll('.nav-btn').forEach(b=>{
    b.addEventListener('click', ()=>switchView(b.dataset.view));
  });

  document.getElementById('start-lockdown-btn').addEventListener('click', ()=>{
    const mins = parseInt(document.getElementById('lockdown-minutes').value)||25;
    const task = document.getElementById('lockdown-task-input').value || 'Focus session';
    startLockdown(mins, task);
  });
  document.getElementById('exit-lockdown-btn').addEventListener('click', ()=>finishLockdown(false));

  document.getElementById('routine-select').addEventListener('change', renderRoutineBlocks);

  document.getElementById('research-add-btn').addEventListener('click', ()=>{
    const title = document.getElementById('research-title').value.trim();
    const stage = document.getElementById('research-stage').value;
    if(!title) return;
    state.research.push({title, stage}); saveState();
    document.getElementById('research-title').value='';
    renderResearch();
  });

  document.getElementById('settings-save-btn').addEventListener('click', ()=>{
    state.profile.persona = document.getElementById('setting-persona').value;
    state.profile.stage = document.getElementById('setting-stage').value;
    state.profile.prayerCity = document.getElementById('setting-city').value;
    state.profile.prayerCountry = document.getElementById('setting-country').value;
    saveState();
    showToast('Settings saved');
    renderDashboard();
  });

  document.getElementById('nutrition-select').addEventListener('change', (e)=>{
    state.prefs.nutrition = e.target.value; saveState();
  });
  document.getElementById('workout-select').addEventListener('change', (e)=>{
    state.prefs.workout = e.target.value; saveState();
  });
}

window.addEventListener('DOMContentLoaded', ()=>{
  wireUp();
  initSettingsForm();
  renderDashboard();
  if (state.prefs.nutrition) document.getElementById('nutrition-select').value = state.prefs.nutrition;
  if (state.prefs.workout) document.getElementById('workout-select').value = state.prefs.workout;
  if ('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js').catch(()=>{});
  }
});
