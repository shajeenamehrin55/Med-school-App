# MedPulse Synergy — Native Android scaffold

This wraps the web app (`app/src/main/assets/web/`) in a WebView and adds
a real `AccessibilityService` (`LockdownAccessibilityService.kt`) that can
detect and interrupt app switches phone-wide — the actual mechanism apps
like Forest/AppBlock use. This is source code, not a compiled app; you
need Android Studio to build it.

## What's real here vs. what you still have to do

**Already written and functionally correct:**
- WebView wrapper loading the full PWA
- `LockdownAccessibilityService` — detects foreground app changes system-wide and re-launches MedPulse if a blocked package opens during an active session
- Accessibility permission request bridge from the web UI
- Manifest wiring, required accessibility description string

**You still need to:**
1. Install **Android Studio** (free), open this folder as a project, let Gradle sync.
2. Add a real launcher icon (`app/src/main/res/mipmap-*/ic_launcher.png`) — currently missing, Studio will flag it.
3. Build & run on a real device or emulator (Accessibility services generally don't behave reliably on some emulators — test on a physical phone).
4. Wire up a simple UI (or the existing WebView Settings screen) to let the user pick *which* apps to block — currently `startLockdown()` takes a comma-separated package list from JS, e.g. `"com.instagram.android,com.google.android.youtube"`.
5. Add the pre-permission disclosure screen Google requires before requesting Accessibility access (a plain-language "why we need this" screen shown *before* the OS prompt).
6. Create a Google Play Developer account ($25 one-time) at https://play.google.com/console
7. Fill out the Play Console **Data Safety** and **Permissions declaration** forms — be explicit that Accessibility is used only for user-initiated app blocking, never for reading screen content.
8. Generate a signed release AAB (`Build > Generate Signed Bundle`), upload to Play Console, submit for review.
9. Expect at least one review round-trip — Accessibility-permission apps are reviewed manually. Have a short demo video ready showing the feature in context.

## Folder structure
```
app/src/main/
  java/com/medpulse/synergy/
    MainActivity.kt                  — WebView host
    LockdownAccessibilityService.kt  — the real app-blocking logic
    LockdownState.kt                 — shared session state
  assets/web/                        — the full PWA (same as the standalone web build)
  res/xml/accessibility_service_config.xml
  res/values/strings.xml
  AndroidManifest.xml
build.gradle / settings.gradle       — top-level Gradle config
```

## Realistic timeline
Native build + testing: a few days to a couple weeks depending on your Android experience.
Play Store review for an Accessibility-permission app: often 1–3 weeks, sometimes longer with resubmissions. Budget for it.
